// ...poprzedni kod...
type CompareRow = {
  codes: string[];
  names: string[];
  offers: ({ price: number | null; available?: string | null; raw?: any } | null)[];
  bestIdx: number;
  priceDiff: number;
};

const [compareRows, setCompareRows] = useState<CompareRow[]>([]);
const [filtr, setFiltr] = useState<string>('');

const handleCompare = async () => {
  const res = await axios.post("http://localhost:3001/api/compare", {
    files: uploaded,
  });
  setCompareRows(res.data.products);
};

// ...w return...

{uploaded.length > 0 && (
  <button onClick={handleCompare}>Porównaj produkty</button>
)}

{compareRows.length > 0 && (
  <div>
    <h2>Tabela porównawcza</h2>
    <input
      type="text"
      placeholder="Filtruj po nazwie produktu..."
      value={filtr}
      onChange={e => setFiltr(e.target.value)}
    />
    <table border={1} cellPadding={4} style={{ width: "100%", marginTop: 12 }}>
      <thead>
        <tr>
          <th>Kod produktu</th>
          <th>Nazwa produktu</th>
          {uploaded.map(f => (
            <th key={f.filename}>{f.filename}<br />Cena</th>
          ))}
          <th>Różnica cen</th>
          <th>Najlepsza oferta</th>
        </tr>
      </thead>
      <tbody>
        {compareRows
          .filter(row =>
            row.names.some(name =>
              name.toLowerCase().includes(filtr.toLowerCase())
            )
          )
          .sort((a, b) => b.priceDiff - a.priceDiff)
          .map((row, idx) => (
          <tr key={idx}>
            <td>{row.codes.join(", ")}</td>
            <td>{row.names[0]}</td>
            {row.offers.map((offer, i) => (
              <td
                key={i}
                style={{
                  background:
                    row.bestIdx === i && offer && offer.price !== null
                      ? "#d4ffd4"
                      : offer && offer.price !== null
                        ? "#fff"
                        : "#fff8c4",
                  fontWeight: row.bestIdx === i ? "bold" : "normal"
                }}
              >
                {offer && offer.price !== null ? offer.price.toFixed(2) : "—"}
              </td>
            ))}
            <td>{row.priceDiff.toFixed(2)}</td>
            <td>
              {row.bestIdx >= 0
                ? uploaded[row.bestIdx].filename
                : '—'}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
)}