// ...poprzedni kod...

import stringSimilarity from 'string-similarity';

// Dopasowanie produktów po kodzie, a gdy go brak – po podobieństwie nazw
function mergeProducts(files) {
  const productMap = new Map();

  files.forEach((file, fileIdx) => {
    file.products.forEach((p) => {
      let key = p.code;
      if (!key || key === '') {
        // Fallback: klucz po nazwie, jeśli bardzo unikalna
        key = p.name.toLowerCase();
      }
      // Jeśli już jest taki kod/nazwa w mapie, to dodaj do tej pozycji
      let existing = productMap.get(key);
      if (!existing) {
        existing = {
          codes: new Set(),
          names: new Set(),
          offers: Array(files.length).fill(null), // [hurtowniaA, hurtowniaB, ...]
        };
      }
      existing.codes.add(p.code);
      existing.names.add(p.name);
      existing.offers[fileIdx] = {
        price: p.price,
        available: p.available,
        raw: p.raw,
      };
      productMap.set(key, existing);
    });
  });

  // Fuzzy match: produkty bez kodu próbujemy dopasować po nazwach
  // (Zaawansowane: można jeszcze robić post-process fuzzy match po nazwach, jeśli trzeba)

  // Zamiana na listę z analizą najlepszej ceny itd.
  const result = [];
  for (let [key, prod] of productMap) {
    const prices = prod.offers.map((o) => (o ? o.price : null));
    const bestIdx = prices.reduce(
      (best, price, idx) =>
        price !== null && (best === -1 || price < prices[best]) ? idx : best,
      -1
    );
    const row = {
      codes: Array.from(prod.codes),
      names: Array.from(prod.names),
      offers: prod.offers,
      bestIdx,
      priceDiff: (() => {
        // Różnica między najwyższą a najniższą ceną (jeśli są min. 2)
        const valid = prices.filter((p) => p !== null);
        if (valid.length < 2) return 0;
        return Math.max(...valid) - Math.min(...valid);
      })(),
    };
    result.push(row);
  }
  return result;
}

app.post('/api/compare', express.json({ limit: '10mb' }), (req, res) => {
  const files = req.body.files; // [{filename, products:[{code,name,price,available}]}]
  if (!files || files.length < 2) {
    return res.status(400).json({ error: 'Prześlij co najmniej dwa pliki.' });
  }
  const products = mergeProducts(files);
  res.json({ products });
});